import React from "react";
import { Link } from "react-router-dom";

export default function Unauthorized() {
  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gray-50">
      <h1 className="text-3xl font-bold text-red-500 mb-4">
        🚫 Access Denied
      </h1>
      <p className="text-gray-700 mb-6">
        You don’t have permission to view this page.
      </p>
      <Link
        to="/Login"
        className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition"
      >
        Go to Login
      </Link>
    </div>
  );
}
